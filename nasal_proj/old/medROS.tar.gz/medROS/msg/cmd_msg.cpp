
#include "cmd_msg.h"
#include "mrl_msg.h"

RBT_CMD_MSG::RBT_CMD_MSG(MRLTYPE t, long s):
MRLmsg(t, s)
{

}
